# Remplace la fonction de lecture d'image (run) de www/index.html par une version plus robuste.
p = "www/index.html"
s = open(p, encoding="utf-8").read()
if "OCR_V2" in s:
    print("patch_html: déjà appliqué")
    raise SystemExit(0)

a = s.index("  async function run(file){")
b = s.index("  function send(mode){")

NEW = r'''  /* OCR_V2 : moteur unique réutilisé, image réduite et remise à l'endroit, progression détaillée, annulation */
  var worker=null,workerP=null,gen=0,lastEvt=0,t0=0,watch=null,cancelRej=null;
  var LABELS={'loading tesseract core':'Chargement du moteur','initializing tesseract':'Démarrage du moteur','loading language traineddata':'Chargement de la langue','initializing api':'Préparation','recognizing text':'Lecture'};
  function elapsed(){return Math.round((Date.now()-t0)/1000)+' s';}
  function onLog(m){
    lastEvt=Date.now();
    var l=LABELS[m.status]||m.status;
    var pc=(typeof m.progress==='number')?' '+Math.round(m.progress*100)+' %':'';
    st.textContent=l+'…'+pc+'  ('+elapsed()+')';
  }
  function stopWatch(){if(watch){clearInterval(watch);watch=null;}}
  function killWorker(){
    gen++;
    var w=worker;worker=null;workerP=null;
    if(w){try{w.terminate();}catch(e){}}
  }
  function cancel(msg){
    if(!busy)return;
    killWorker();
    if(cancelRej)cancelRej(new Error(msg||'Lecture annulée.'));
  }
  function getWorker(){
    if(worker)return Promise.resolve(worker);
    if(workerP)return workerP;
    var my=gen;
    workerP=Tesseract.createWorker('fra',1,{
      workerPath:abs('tesseract/worker.min.js'),
      langPath:abs('lang'),
      corePath:abs('tesseract/tesseract-core.wasm.js'),
      logger:onLog
    }).then(function(w){
      if(my!==gen){try{w.terminate();}catch(e){}throw new Error('Lecture annulée.');}
      worker=w;return w;
    },function(e){workerP=null;throw e;});
    return workerP;
  }
  async function prepare(file){
    var MAX=2200,bmp;
    try{bmp=await createImageBitmap(file);}
    catch(e){
      bmp=await new Promise(function(ok,ko){
        var im=new Image();
        im.onload=function(){ok(im);};
        im.onerror=function(){ko(new Error('image illisible'));};
        im.src=lastUrl;
      });
    }
    var w=bmp.width||bmp.naturalWidth,h=bmp.height||bmp.naturalHeight;
    var k=Math.min(1,MAX/Math.max(w,h));
    var cw=Math.max(1,Math.round(w*k)),ch=Math.max(1,Math.round(h*k));
    var cv=document.createElement('canvas');cv.width=cw;cv.height=ch;
    var cx=cv.getContext('2d',{willReadFrequently:true});
    cx.drawImage(bmp,0,0,cw,ch);
    if(bmp.close)bmp.close();
    var img=cx.getImageData(0,0,cw,ch),d=img.data,sum=0,n=0,i,g;
    for(i=0;i<d.length;i+=16){sum+=d[i]*0.299+d[i+1]*0.587+d[i+2]*0.114;n++;}
    var dark=(sum/n)<110;            /* texte clair sur fond sombre : on inverse */
    for(i=0;i<d.length;i+=4){
      g=d[i]*0.299+d[i+1]*0.587+d[i+2]*0.114;
      if(dark)g=255-g;
      d[i]=d[i+1]=d[i+2]=g;
    }
    cx.putImageData(img,0,0);
    return cv;
  }

  async function run(file){
    if(!file||busy)return;
    setBusy(true);
    raw='';res.value='';
    if(lastUrl)URL.revokeObjectURL(lastUrl);
    lastUrl=URL.createObjectURL(file);
    prev.src=lastUrl;
    open();
    var cancelP=new Promise(function(_,ko){cancelRej=ko;});
    cancelP.catch(function(){});
    t0=Date.now();lastEvt=t0;
    stopWatch();
    watch=setInterval(function(){
      if(busy&&Date.now()-lastEvt>180000)cancel('Le moteur ne répond plus (3 min sans progrès). Ferme cette fenêtre et réessaie.');
    },5000);
    try{
      if(location.protocol==='file:')throw new Error('la lecture d’image ne marche pas depuis un fichier local — utilise l’app installée ou hébergée');
      st.textContent='Préparation de l’image…';
      var cv=await Promise.race([prepare(file),cancelP]);
      st.textContent='Chargement du moteur…';
      await Promise.race([loadTess(),cancelP]);
      var w=await Promise.race([getWorker(),cancelP]);
      lastEvt=Date.now();
      var out=await Promise.race([w.recognize(cv),cancelP]);
      raw=(out&&out.data&&out.data.text)||'';
      res.value=format(raw);
      st.textContent=res.value?('Terminé en '+elapsed()+' — relis et corrige si besoin.'):'Aucun texte détecté. Recadre la photo et réessaie.';
    }catch(err){
      console.error(err);
      st.textContent='Erreur : '+(err&&err.message?err.message:err);
    }finally{
      stopWatch();cancelRej=null;
      setBusy(false);
    }
  }
  $('ocrClose').addEventListener('click',function(){if(busy)cancel('Lecture annulée.');});

'''
s = s[:a] + NEW + s[b:]
open(p, "w", encoding="utf-8").write(s)
print("patch_html: appliqué")
