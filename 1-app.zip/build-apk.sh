#!/usr/bin/env bash
# Construit l'APK (debug) à partir du dossier www/ avec Capacitor.
set -euo pipefail
export CI=true

test -f www/index.html || { echo "www/index.html manquant"; exit 1; }
test -f www/lang/fra.traineddata.gz || { echo "www/lang/ manquant (dépose aussi 2-lang.zip)"; exit 1; }

npm init -y >/dev/null
npm i --no-audit --no-fund @capacitor/core@6 @capacitor/cli@6 @capacitor/android@6
npx cap telemetry off || true
npx cap init "F(X) Karaoke" com.fxkaraoke.app --web-dir www
npx cap add android

# Autorisation caméra (bouton PHOTO)
MANIFEST=android/app/src/main/AndroidManifest.xml
grep -q 'android.permission.CAMERA' "$MANIFEST" || \
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.CAMERA" />\n</manifest>#' "$MANIFEST"

# Icône de l'app (si ça échoue, l'icône Capacitor par défaut reste)
pip install --quiet pillow || true
python3 - <<'PY' || echo "Icône par défaut conservée"
import glob, os, shutil
from PIL import Image
res = "android/app/src/main/res"
sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
src = Image.open("www/icon-512.png").convert("RGBA")
for d, px in sizes.items():
    folder = f"{res}/mipmap-{d}"
    os.makedirs(folder, exist_ok=True)
    im = src.resize((px, px), Image.LANCZOS)
    for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
        im.save(f"{folder}/{name}")
shutil.rmtree(f"{res}/mipmap-anydpi-v26", ignore_errors=True)
PY

npx cap sync android
(cd android && chmod +x gradlew && ./gradlew --no-daemon assembleDebug)
cp android/app/build/outputs/apk/debug/app-debug.apk FX-Karaoke.apk
ls -lh FX-Karaoke.apk
