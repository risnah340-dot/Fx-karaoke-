/* Boutons flottants PHOTO / IMAGE (visibles sans défiler). Sans effet s'ils existent déjà. */
(function () {
  function init() {
    if (document.getElementById('scanFab')) return;
    var cam = document.getElementById('scanCameraInput');
    var gal = document.getElementById('scanGalleryInput');
    if (!cam || !gal) return;
    var st = document.createElement('style');
    st.textContent =
      '#scanFab{position:fixed;right:12px;bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:40;display:flex;gap:10px}' +
      '#scanFab button{width:56px;height:56px;border-radius:28px;border:2px solid #a855f7;background:#1a1a1a;color:#fff;font-size:24px;line-height:1;box-shadow:0 4px 16px #000a}' +
      '#scanFab button:last-child{background:#a855f7}' +
      '#scanFab button:active{transform:scale(.94)}';
    document.head.appendChild(st);
    var box = document.createElement('div');
    box.id = 'scanFab';
    box.innerHTML =
      '<button type="button" id="scanFabGallery" aria-label="Lire une image de la galerie" title="Image de la galerie">🖼</button>' +
      '<button type="button" id="scanFabCamera" aria-label="Prendre une photo et la lire" title="Prendre une photo">📸</button>';
    document.body.appendChild(box);
    document.getElementById('scanFabCamera').addEventListener('click', function () { cam.click(); });
    document.getElementById('scanFabGallery').addEventListener('click', function () { gal.click(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
